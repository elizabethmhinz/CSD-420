// M7 Program for CSD420-A339: Advanced Java created by Liz Hinz
// Program displays 4 circles and uses the style class & ID

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class Circles extends Application {
	// Started with code from 31.2 from textbook 
	@Override // Override the start method in Application class
	public void start(Stage primaryStage) {
		HBox hBox = new HBox(10);
		Scene scene = new Scene(hBox, 350, 200);
		scene.getStylesheets().add("Circles.css"); // Load style sheet
		
		// Create wrapper class to add border around circle1
		Pane circle1Wrapper = new Pane();
		circle1Wrapper.getStyleClass().add("border1");
        circle1Wrapper.setMinSize(80, 200); // Set size
        circle1Wrapper.setMaxSize(80, 200); // Set size
        
		HBox.setMargin(circle1Wrapper, new Insets(0, 0, 0, 10)); // Set margin to look like exercise pic

		Circle circle1 = new Circle(40, 60, 30);
		circle1.getStyleClass().add("circle1"); // Add style class
		circle1Wrapper.getChildren().add(circle1);
		
		Pane pane1 = new Pane();
		pane1.setPrefSize(220, 120);
		
		Circle circle2 = new Circle(35, 60, 30);
		Circle circle3 = new Circle(110, 60, 30);
		Circle circle4 = new Circle(185, 60, 30);
		
		circle2.getStyleClass().add("circle2"); // Add style class
		circle3.getStyleClass().add("circle3"); // Add style class
		circle4.setId("circle4");
		
		pane1.getChildren().addAll(circle2, circle3, circle4);
		pane1.setPrefSize(240, 120);

		hBox.getChildren().addAll(circle1Wrapper, pane1);
		
		primaryStage.setTitle("Hinz - M7 Programming Assignment"); // Set window title
		primaryStage.setScene(scene); // Place scene in window
		primaryStage.show(); // Display window
		}
// 
	
	// Main method for IDEs with limited JavaFX support
	public static void main(String[] args) {
		launch(args);
	}
}