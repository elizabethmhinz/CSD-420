// M2 Programming Assignment created by Liz Hinz for CSD420-A339
// Program generates 5 random integers & double values & writes them to a file
import java.io.*;
import java.util.Random;

public class RandomArrays {
	public static void main(String[] args){
		// Create random int & random double arrays
		int[] randomIntegers = new int[5];
		double[] randomDoubles = new double[5];
		Random random = new Random();
		
		// Add random numbers to array
		for (int i = 0; i < 5; i++) {
			randomIntegers[i] = random.nextInt(1000);
			randomDoubles[i] = random.nextDouble() * 1000;
		}
		
		try{
			// Create random access file
			RandomAccessFile randomAccessFile = new RandomAccessFile("LizHinz_datafile.dat", "rw");
			
			// Clear file to destroy old contents if exists
			randomAccessFile.setLength(0);
			
			// Go to end of file
			randomAccessFile.seek(randomAccessFile.length());
			
			// Write ints to file
			for (int num : randomIntegers){
				randomAccessFile.writeInt(num);
			}
		  
			// Write doubles to file
			for (double num: randomDoubles){
				randomAccessFile.writeDouble(num);
			}
			// Close file
			randomAccessFile.close();  
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}