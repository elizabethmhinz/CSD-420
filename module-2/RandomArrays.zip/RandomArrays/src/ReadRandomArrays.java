// M2 Programming Assignment created by Liz Hinz for CSD420-A339
// Program reads the Random Arrays created in RandomArrays.java class 
import java.io.*;

public class ReadRandomArrays {
	public static void main(String[] args) {
		String fileName = "LizHinz_datafile.dat";

		try {
			// Create random access reader 
			RandomAccessFile randomAccessFile = new RandomAccessFile(fileName, "r");
			
			// Read & display arrays in file
			System.out.println(fileName + " data successfully added to file.");
	        while (randomAccessFile.getFilePointer() < randomAccessFile.length()) {
	        	int intValue = randomAccessFile.readInt();
	        	System.out.println("Random Integers: " + intValue);
	        	
	        	double doubleValue = randomAccessFile.readDouble();
	        	System.out.println("Random Doubles: " + doubleValue);
	          }
			// Close file
			randomAccessFile.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
