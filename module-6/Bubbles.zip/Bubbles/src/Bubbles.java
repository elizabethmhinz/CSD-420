/* Program created by Liz Hinz for CSD420-A339 M6 Program
 * Program with 2 generic methods using bubble sort. Sorts with
 * Comparable then comparator 
 */
import java.util.Comparator;

public class Bubbles {
	// Code from professor, using comparable interface
	public static <E extends Comparable<E>> void bubbleSort(E[]list) {
		// Started with code from 23.4 in book, loop through array
		for(int i = 0; i < list.length - 1; i++) {
			// Compare elements
			for(int j = 0; j < list.length - 1 - i; j++) {
				if(list[j].compareTo(list[j + 1]) > 0){
				// Swap elements 
				E temp = list[j]; // temp for swapping
				list[j] = list[j + 1];
				list[j + 1] = temp;
				}
			}
		}
	}
	// Code from professor, using comparator 
	public static <E> void bubbleSort(E[] list, Comparator <? super E> comparator) {
		// Started with code from 23.4 in book, loop through array
		for(int i = 0; i < list.length - 1; i++) {
			// Compare elements 
			for(int j = 0; j < list.length - 1 - i; j++) { 
				if(comparator.compare(list[j], list[j+1]) > 0){ 
				// Swap elements with comparator 
				E temp = list[j]; // temp for swapping
				list[j] = list[j + 1];
				list[j + 1] = temp;
				}
			}
		}
	}
	  public static void main(String[] args) {
		  // Test method for the comparable interface
		  Integer[] list1 = {7, 12, 8, 61, 41, 2, 3, 14, 32};
		  bubbleSort(list1);
		  System.out.print("Sorted using Comparable Interface: ");
		  for (int i : list1) {
			  // Display sorted array
			  System.out.print(i + " ");
		  }
		  System.out.println();
		  
		  // Test method for comparator
		  Integer[] list2 = {74, 7, 81, 3, 10, 9, 62, 88, 91};
		  bubbleSort(list2, new Comparator<Integer>() {
			  @Override
			  // Sort array using compare
			  public int compare(Integer a, Integer b) {
				  return a.compareTo(b);
			  }
		  });
		  // Display sorted array
		  System.out.print("Sorted using Comparator Interface: ");
		  for (int i : list2) {
			  System.out.print(i + " ");
		  }
	}
}