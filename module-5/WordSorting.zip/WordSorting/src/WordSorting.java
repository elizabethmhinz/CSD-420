/* Program created by Liz Hinz for CSD420-A339 M5 Program
   Reads & displays non-dup words from a text file in ascending 
   & descending order */
import java.io.*;
import java.util.*; 

public class WordSorting {
	public static void main(String[] args) {
		String fileName = "collection_of_words.txt";
		File file = new File(fileName);
		
		// Added line because was having issues with the path, ended up moving it to project folder
		if (!file.exists()) {
		    System.out.println("File does not exist at the specified path.");
		} else {
		    System.out.println("File exists!");
		}
		// Also, added because of issues with file path
		System.out.println("File Path: " + file.getAbsolutePath());

		// Create TreeSet set. Using a set to eliminate duplicates 
		Set<String> set = new TreeSet<>();
		
		// Read contents of file
		try {
			BufferedReader input = new BufferedReader(new FileReader(file));
			String line;
			while ((line = input.readLine()) != null) {
				String[] words = line.split("\\s +");
				Collections.addAll (set, words);
			} 
			input.close();
		} catch (IOException e) {
			System.out.println("Error occured." + e.getMessage());
		}
		
		// Display the elements in ascending order 
		System.out.println("\nWords in ascending order without duplicates: "); 
		for(String s : set) {
			System.out.print(s + ", ");
		}
		System.out.println();
		
		// Reverse set order by converting to a list
		List<String> list = new ArrayList<>(set);
		Collections.reverse(list);
		
		// Display elements in descending order 
		System.out.println("\nWords in descending order wihtout duplicates:");
		for (String s: list) {
			System.out.print(s + " ");
		}
		System.out.println();
		
		// Create test set
		Set<String> testSet = new TreeSet<>();

		// Add strings to the set 
		testSet.add("Whiplash");
		testSet.add("Parasite");
		testSet.add("It");
		testSet.add("Emma");
		testSet.add("Signs");
		testSet.add("Midsommar");
		testSet.add("Companion"); 
		testSet.add("It");
		testSet.add("Whiplash");
		
		System.out.println("\n\nTest Code:");
		System.out.println("Words in ascending order without duplicates: ");
		for (String word : testSet) {
			System.out.print(word + " ");
		}
		System.out.println();
		
		// Reverse set order by converting to a list
		List<String> testList = new ArrayList<>(testSet);
		Collections.reverse(testList);
		
		// Display elements in descending order 
		System.out.println("\nWords in descending order wihtout duplicates:");
		for (String s: testList) {
			System.out.print(s + " ");
		}
		System.out.println();
	}
}
