/* M4 Programming code created by Liz Hinz for CSD420-A339
* Test program that stores 50,000 ints then 500,000 in LinkedList. 
* Test time to traverse 
* used https://www.tutorialspoint.com/java/lang/system_nanotime.htm for timing code
*/

import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Random;

public class LinkedListTest {
	public static void main(String[] args) {
		// Create random int linked list
		LinkedList<Integer> linkedList = new LinkedList<>();
		Random random = new Random();
	
		// Add random ints to linked list
		for (int i = 0; i < 50000; i++) {
		//for (int i = 0; i < 500000; i++) {
			linkedList.add(random.nextInt(101)); // 0-100
		}
		// Track time to traverse using Iterator 
		long startTime = System.nanoTime();
		int sumIterator = 0;
		ListIterator<Integer> listIterator = linkedList.listIterator();
		while (listIterator.hasNext()) {
			sumIterator += listIterator.next();
		}
		long endTime = System.nanoTime();
		/* Program took 5757209 nanoseconds to traverse using Iterator for 50,000 integers
		 * Program took 3705209 nanoseconds to traverse using Iterator for 50,000 integers after running twice
		 * Program took 7479333 nanoseconds to traverse using Iterator for 500,000 integers
		 * Program took 8262083 nanoseconds to traverse using Iterator for 500,000 integers after running twice
		 * These tests prove that traversing using Iterator is much more efficient than using get(index) method */ 
		
		System.out.println("Program took " + (endTime - startTime) + " nanoseconds to traverse using Iterator");
		
		// Track time to traverse using get(index) method
		startTime = System.nanoTime();
		int sumGet = 0;
		
		// Code from section 20.5 of textbook
		for (int i = 0; i < linkedList.size(); i++) {
			sumGet += linkedList.get(i); // Get index method
		}
		endTime = System.nanoTime();
		
		/* Program took 1863448167 nanoseconds to traverse using get(index) method for 50,000 integers
		 * Program took 1626199750 nanoseconds to traverse using get(index) method for 50,000 integers after running twice
		 * Program took 169630961708 nanoseconds to traverse using get(index) method for 500,000 integers 
		 * Program took 167691185625 nanoseconds to traverse using get(index) method for 500,000 integers after running twice
		 * These tests prove that traversing using the get(index) method is much less efficient than using Iterator */
		
		System.out.println("Program took " + (endTime - startTime) + " nanoseconds to traverse using get(index) method");

	}
}
