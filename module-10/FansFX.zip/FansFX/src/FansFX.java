// M10 Program created by Liz Hinz for CSD420-A339
// Program views & updates fan info stored in databasedb w/ user id student1 & pass as password

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

// Used parts of the code from listing 34.2 & adjusted parts as needed
public class FansFX extends Application {
	private Connection connection; // establish connection 
	// Statement to execute queries & text fields for user input
	private Statement stmt;
	private TextField tfID = new TextField();
	private TextField tfFirstName = new TextField();
	private TextField tfLastName = new TextField();
	private TextField tfFavoriteTeam = new TextField();
	private Label lblStatus = new Label(); // Display status
	
	@Override // Override the Application class
	public void start(Stage primaryStage) {
		// Initialize database connection & create statement object
		initializeDB();
		
		// Display fan info button
		Button btDisplay = new Button("Display");
		btDisplay.setOnAction(e -> displayFan());
		
		// Update fan info button
		Button btUpdate = new Button("Update");
		btUpdate.setOnAction(e -> updateFan());
		
		// Hbox for user input & buttons
		HBox hBox = new HBox(5);
		hBox.getChildren().addAll(new Label("ID"), tfID, btDisplay, btUpdate);
		
		// Vbox for input fields & status
		VBox vBox = new VBox(10);
		vBox.getChildren().addAll(hBox, 
				new Label("First Name"), tfFirstName, 
				new Label("Last Name"), tfLastName,
				new Label("Favorite Team"), tfFavoriteTeam,
				lblStatus);
		
		// Create a scene & place it in the stage
		Scene scene = new Scene(vBox, 400, 250);
		primaryStage.setTitle("Fans");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	private void initializeDB() {
		// Load JDBC driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(
		          "jdbc:mysql://localhost:3306/databasedb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
		          "student1", "pass");
			
			stmt = connection.createStatement();
			lblStatus.setText("Database connected successfully.");
			
			} catch (Exception e) {
				lblStatus.setText("Database connection failed: " + e.getMessage());
				e.printStackTrace();
			}
		}
	// Display fan info
	private void displayFan() {
		try {
			int id = Integer.parseInt(tfID.getText().trim()); // Parse ID
			String queryString = "SELECT * FROM fans WHERE ID = " + id; // Create SQL query
			ResultSet rs = stmt.executeQuery(queryString); // Execute & store query
			if(rs.next()) {
				tfFirstName.setText(rs.getString("firstname"));
				tfLastName.setText(rs.getString("lastname"));
				tfFavoriteTeam.setText(rs.getString("favoriteteam"));
				lblStatus.setText("Record displayed.");
			} else {
				lblStatus.setText("No record found for ID: " + id);
			}
		} catch (Exception e) {
			lblStatus.setText("Error displaying record: " + e.getMessage());
		}
	}
	
	// Update fan info
	private void updateFan() {
		try {
			int id = Integer.parseInt(tfID.getText().trim()); // Parse ID
			// Get updated values
			String firstName = tfFirstName.getText().trim();
			String lastName = tfLastName.getText().trim();
			String favoriteTeam = tfFavoriteTeam.getText().trim();
			
			// Create SQL statement 
			String queryString = "UPDATE fans SET firstname = '" + firstName + 
					"', lastname = '" + lastName + 
					"', favoriteteam = '" + favoriteTeam + 
					"' WHERE ID = " + id;
			
			int rowsAffected = stmt.executeUpdate(queryString); // Execute update statement
			
			// Make sure records were successful, display if so & if not 
			if(rowsAffected > 0) {
				lblStatus.setText("Record successfully updated.");
			} else {
				lblStatus.setText("No records found for ID: " + id);
			}
		} catch (Exception e) {
			lblStatus.setText("Error updating record: " + e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		// Main method for IDEs with limited JavaFX support
		launch(args);
	}
}