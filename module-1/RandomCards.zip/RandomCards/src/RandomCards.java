// Program created by Liz Hinz for CSD420-A339: Advanced Java Programming
// M1 Programming Assignment - generate 4 random cards from 54 card deck

import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class RandomCards extends Application {
	private List<Image> images = new ArrayList<>();
	private ImageView[] imageViews = new ImageView[4];
	
	@Override // Override Application class 
	public void start(Stage stage) throws Exception {
        // Load images from the cards folder in resources 
        String[] imagePaths = {
        	"/cards/1.png", "/cards/2.png", "/cards/3.png", "/cards/4.png","/cards/5.png","/cards/6.png",
        	"/cards/7.png", "/cards/8.png", "/cards/9.png", "/cards/10.png","/cards/11.png","/cards/12.png",
        	"/cards/13.png", "/cards/14.png", "/cards/15.png", "/cards/16.png","/cards/17.png","/cards/18.png",
        	"/cards/19.png", "/cards/20.png", "/cards/21.png", "/cards/22.png","/cards/23.png","/cards/24.png",
        	"/cards/25.png", "/cards/26.png", "/cards/27.png", "/cards/28.png","/cards/29.png","/cards/30.png",
        	"/cards/31.png", "/cards/32.png", "/cards/33.png", "/cards/34.png","/cards/35.png","/cards/36.png",
        	"/cards/37.png", "/cards/38.png", "/cards/39.png", "/cards/40.png","/cards/41.png","/cards/42.png",
        	"/cards/43.png", "/cards/44.png", "/cards/45.png", "/cards/46.png","/cards/47.png","/cards/48.png",
        	"/cards/49.png", "/cards/50.png", "/cards/51.png", "/cards/52.png","/cards/53.png","/cards/54.png", 
        };
        
        // Load images into the images list
        for (String imagePath : imagePaths) {
            System.out.println("Loading image: " + imagePath);  // Debugging
            Image image = new Image(getClass().getResource(imagePath).toString());
            images.add(image);
        }
		
        // Display the cards through ImageView objects
		for (int i = 0; i < imageViews.length; i++) {
			imageViews[i] = new ImageView();
			imageViews[i].setFitWidth(75);
			imageViews[i].setFitHeight(100);
		}
		
	    // Create the refresh Button, using a Lambda expression
	    Button button = new Button("Refresh");
        button.setOnAction(e -> displayRandomCards()); 
        
        // Create label 
	    Label label = new Label("Draw your cards!");
	    label.setContentDisplay(ContentDisplay.BOTTOM);
	    label.setTextFill(Color.BLUE);
	    
        // create a HBox & set the layout
        VBox vbox = new VBox(20);
        vbox.setAlignment(Pos.CENTER); 
        
        // Add images to VBox with label 
        vbox.getChildren().add(label);
        for (ImageView imageView : imageViews) {
        	vbox.getChildren().add(imageView);
        }
        vbox.getChildren().add(button);
        
	    // Display cards
	    displayRandomCards();
	    
    	// Create scene, set stage title, set scene & show scene
    	Scene scene = new Scene(vbox, 600, 600);
    	stage.setTitle("Random Card Generator");
    	stage.setScene(scene);
	    stage.show();
	}
	// Display method for the 4 cards 
	private void displayRandomCards() {
		Collections.shuffle(images); // Shuffle images
		for (int i = 0; i < imageViews.length; i++) {
			if (i < images.size()) {
				imageViews[i].setImage(images.get(i)); // Set random cards
			} else {
				imageViews[i].setImage(null); // nulls more than 4 cards
			}
		}
	}

	// Main method for IDEs with limited JavaFX support
	public static void main(String[] args) {
		launch(args);
	}
}
