// Line example created by Liz Hinz for CSD420-A339
// M1 Discussion Board - JavaFX Line Example

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class LineExample extends Application{

	@Override // Override the start method in the Application class
	public void start(Stage primarystage) throws Exception {
		
		// create line object
		Line line = new Line();
		
		// create stage object
		Stage stage = new Stage();

		// set line properties  
		line.setStartX(70.0);
		line.setStartY(75.0);
		line.setEndX(200.0);
		line.setEndY(300.0);
		
		// Create group
		Group root = new Group(line);
		
		// Create scene
		Scene scene = new Scene(root, 200, 200);
		
		stage.setTitle("Line Example");
		
		// Set scene
		stage.setScene(scene);
		
		// Show stage
		stage.show();
		
	}
	// main method for IDEs with limited JavaFX support
	public static void main(String[] args) {
		launch(args);
	}
	
	
}