//Text example created by Liz Hinz for CSD420-A339
//M1 Discussion Board - JavaFX Text Example

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.text.*;

public class TextEx extends Application {
	
	@Override // Override application
	public void start(Stage primaryStage) {
		Text textEx = new Text("Text for M1 Discussion Post!");
		
		// Set style
		textEx.setFont(Font.font("Courier New", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 10));
		
		// Set position 
		textEx.setX(30);
		textEx.setY(40);
			
		// Group object 
		Group root = new Group(textEx);
		
		// Create scene
		Scene scene = new Scene(root, 100, 100);
		
		// Set stage
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	// main method for IDEs with limited JavaFX support
	public static void main(String[] args) {
		launch(args);
	}

}