// M8 Program for CSD420-A339: Advanced Java created by Liz Hinz
// Program uses three threads to output random letters, digits, & characters

import java.util.Random;

public class LizThreeThreads implements Runnable {
	// Set output value to 10,000 to use with int, char, & string values
	private static final int OUTPUT_COUNT = 10000;
	private String type;
	
	public LizThreeThreads(String type) {
		this.type = type;
	}
	
	public static void main(String[] args) {
		Thread thread1 = new Thread(new LizThreeThreads("randomLetters")); // Thread for random characters
		Thread thread2 = new Thread(new LizThreeThreads("randomNumbers")); // Thread for random numbers
		Thread thread3 = new Thread(new LizThreeThreads("randomSpecial")); // Thread for random character
		
		// Name threads
		thread1.setName("Thread 1: ");
		thread2.setName("Thread 2: ");
		thread3.setName("Thread 3: ");

		thread1.start();
		thread2.start();
		thread3.start();
		
		try {
			thread1.join();
			thread2.join();
			thread3.join();
		} catch (Exception e) {
			System.out.println("Exception found: " + e.getMessage());
		}
	}
	@Override
	public void run() {
		Random random = new Random(); // Generate random numbers
		StringBuilder output = new StringBuilder();
		
		// Loop with switch statements to generate thread values 
		for (int i = 0; i < OUTPUT_COUNT; i++) {
			switch (type) {
				case "randomLetters":
					char letter = (char) ('a' + random.nextInt(26)); // Generates random letters
					output.append(letter + " ");
					break;
					
				case "randomNumbers":	
					int number = random.nextInt(100); // Generates random numbers
					output.append(number + " ");
					break; 
					
				case "randomSpecial":
					char[] specialChars = {'!', '@', '#', '$', '%', '&', '*'}; // Set special characters 
					char specialChar = specialChars[random.nextInt(specialChars.length)];
					output.append(specialChar + " ");
					break; 
			}
		}
		// Test that code works by printing threads 
		System.out.println(Thread.currentThread().getName() + output.toString());
	}
}
