// M3 Programming code created by Liz Hinz for CSD420-A339
// Test program that contains a static method that returns a new ArrayList 
//
import java.util.ArrayList;
import java.util.Random;

public class ArrayTest {		
		
	public static void main(String[] args){
		// Create random int arrays
		ArrayList<Integer> list = new ArrayList<>();
		Random random = new Random();
		
		// Add random ints to array
		for (int i = 0; i < 50; i++) {
			list.add(random.nextInt(20) + 1); // Plus 1 so it's 1-20 instead of 0-19
		}
		// Print random ints array
		System.out.println("Original Array List: " + list);
		
		// Get list1 from static method 
		ArrayList<Integer> list1 = removeDuplicates(list);
		
		// Print random ints array with duplicates removed 
		System.out.println("Array List without Duplicates: " + list1);
	}
	// Return list without any duplicate numbers using static method
	public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list) {
		ArrayList<E> list1 = new ArrayList<>();
		for (E item : list) {
			if (!list1.contains(item)) {
				list1.add(item);
			}
		}
		return list1;	
	}
}